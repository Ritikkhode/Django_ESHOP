from django.shortcuts import render, redirect
from django.contrib.auth.hashers import check_password
from Buy.models.customer import Customer
from django.views import View
from Buy.models.product import Product

class Cart(View):
    def get(self , request):
        ids = list(list(request.session.get('cart').keys()))
        product = Product.get_products_by_id(ids)
        print(product)
        return render(request, 'cart.html' , {'products' : product} )



